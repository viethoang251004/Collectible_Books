import numpy as np
import math as m
def vx(x):
    if x >= 0:
        return x
    else:
        return -x
def maxmin(fx):
    M = round(max(fx),2)
    print("max= ",M)
    m = round(min(fx),2)
    print("min= ",m)
a = b = c = d = e = []
for x in np.arange(-2.1, 2.1, 0.1):
    a = (x, (2 + ((x ** 2 / (x ** 2 + 4)))))
maxmin(a)
for x in np.arange(-0.1, 5.1, 0.1):
    b = (x, m.sqrt(5 * x + 10))
maxmin(b)
for x in np.arange(4.9, 10.1, 0.1):
    c = (x, (2 / (x ** 2 - 16)))
maxmin(c)
for x in np.arange(-3.1, 3.1, 0.1):
    d = (x, x ** 4 + 3 * x ** 2 - 1)
maxmin(d)
x = np.arange(-3.1, 3.1, 0.1)
e = list(map(vx,x))
maxmin(e)