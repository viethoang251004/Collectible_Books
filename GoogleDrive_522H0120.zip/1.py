for i in range(50,101) :
    if i%2==0 :
        print(i)