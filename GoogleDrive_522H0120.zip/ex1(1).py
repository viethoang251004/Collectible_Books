import math
#cau a
def f1(x):
    return math.sqrt(x)
#cau b
def f2(x):
    return (x ** 1 / 3)
#cau c
def f3(x):
    return (x ** 2 / 3)
#cau d
def f4(x):
    return ((x ** 3) / 3 - (x ** 2) / 2 - 2 * x + 1 / 3)
#cau e
def f5(x):
    return ((2 * x ** 2 - 3) / (7 * x +4))
#cau f
def f6(x):
    return ((5 * x ** 2 + 8 * x - 3) / (3 * x ** 2 + 2))
#cau g
def f7(x):
    return (math.sin(x))
#cau h
def f8(x):
    return (math.cos(x))
#cau i
def f9(x):
    return (3 ** x)
#cau j
def f10(x):
    return (10 ** (-x))
#cau k
def f11(x):
    return (math.e ** x)
#cau l
def f12(x):
    return (math.log2(x))
#cau m
def f13(x):
    return (math.log10(x))
#cau n
def f14(x):
    return (math.log(x))
#main
print(f1(1))
print(f2(2))
print(f3(3))
print(f4(4))
print(f5(5))
print(f6(6))
print(f7(7))
print(f8(8))
print(f9(9))
print(f10(10))
print(f11(11))
print(f12(12))
print(f13(13))
print(f14(14))