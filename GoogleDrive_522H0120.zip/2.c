#include <stdio.h>
#include <math.h>
int main()
{
	int a,b;
	int perimeter, area;
	printf("Input a length of a rectangle: ");
	scanf("%d", &a);
	printf("Input a width of a rectangle: ");
	scanf("%d", &b);
	perimeter = (a + b) * 2;
	area = a * b;
	printf("Output the perimeter of the rectangle: %d\n", perimeter);
	printf("Output the area of the rectangle: %d\n", area);
	return 0;
}