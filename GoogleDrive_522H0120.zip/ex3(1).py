import numpy as np
import math as m
f1 = lambda x: x + 5
f2 = lambda x: x ** 2 - 3
print(f1(f2(0)))
print(f2(f1(0)))
print(f1(f1(-5)))
print(f2(f2(2)))