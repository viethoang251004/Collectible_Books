import numpy as np
import matplotlib.pyplot as plt
import math as m
def monotony(fx, n):
    x = np.arange(-10, 10.1, 0.1)
    x = x + n
    y = list(map (fx, x))
    plt.plot(x, y, color = 'red')
    plt.grid()
    plt.show()
i = lambda x: -x ** 3
print("i)Decreasing in range (-inf,+inf)")
monotony(i,0)
j = lambda x: -1 / (x ** 2)
print("j)Decreasing in range (-inf,0) and increasing in range (0,+inf)")
monotony(j,2)
k = lambda x: -1/x
print("k)Increasing in range(-inf,0) and (0,+inf)")
monotony(k,3)
l = lambda x: 1 / abs(x)\
print("l)Increasing in range(-inf,0) and decreasing in range (0,+inf)")
monotony(1,-2)
m = 