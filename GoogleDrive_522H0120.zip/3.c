#include <stdio.h>
int main()
{	
	int m, h, tongtien;
	printf("Nhap so gio lam viec: ");
	
	scanf("%d", &h);

	printf("Nhap gio cong tieu chuan: ");
	
	scanf("%d", &m);
	
	tongtien = m*h;
	
	if( h > 40 & h <= 45)
	{
		tongtien = m*h*1.8;
	}
	
	if( h > 45 & h <= 50)
	{
		tongtien = m*h*2.5;
	}
	
	if( h > 50)
	{
		tongtien = m*h*2.6;
	}

	printf("Tong so tien nhan vien thu thap duoc trong tuan la: %d", tongtien);

	return 0;
}